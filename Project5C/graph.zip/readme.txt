graph1.txt - 5 nodes, connected
graph2.txt - 10 nodes, connected
graph3.txt - 50 nodes, connected, end node is not reachable from the start
graph4.txt - 100 nodes, connected
graph5.txt - 200 nodes, connected
graph6.txt - 5 nodes, connected, no negative cycles
graph7.txt - 10 nodes, connected, no negative cycles
graph8.txt - 20 nodes, end node is not reachable from start node, no negative cycles
graph9.txt - 100 nodes, connected, negative cycle is reachable from start node
graph10.txt - 200 nodes, end node is not reachable from start node, negative cycle is reachable from start node